# ECMAScript 6 Class 的基本语法

----


- [1] - Object.is()
- [2] - Object.assign()
- [3] - Object.getOwnPropertyDescriptors()
- [4] - _proto__属性，Object.setPrototypeOf()，Object.getPrototypeOf()
- [5] - Object.keys()，Object.values()，Object.entries()
- [6] - Object.fromEntries()


### 1、Object.is
