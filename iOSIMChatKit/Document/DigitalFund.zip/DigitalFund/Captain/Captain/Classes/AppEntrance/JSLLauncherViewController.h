

#import "JSLBaseCommonViewController.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^JSLLauncherADPageBlock)(void);

@interface JSLLauncherViewController : JSLBaseCommonViewController

@property (nonatomic, copy) JSLLauncherADPageBlock doAfterLauncherADPage;

@end

NS_ASSUME_NONNULL_END
