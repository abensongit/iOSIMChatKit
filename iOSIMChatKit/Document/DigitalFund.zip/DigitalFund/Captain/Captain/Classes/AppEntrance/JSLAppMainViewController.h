

#import "JSLSafariViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface JSLAppMainViewController : JSLSafariViewController

@end

NS_ASSUME_NONNULL_END
