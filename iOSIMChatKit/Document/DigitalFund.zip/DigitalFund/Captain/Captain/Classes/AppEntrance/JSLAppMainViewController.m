#import "JSLAppMainViewController.h"

@interface JSLAppMainViewController ()

@end

@implementation JSLAppMainViewController


#pragma mark - Navigation

- (BOOL)prefersStatusBarHidden
{
    return NO;
}

- (BOOL)prefersNavigationBarHidden
{
    return YES;
}


#pragma mark -
#pragma mark 请求刷新网址（子类继承）
- (NSString *)webViewLoadRequestURLStrring
{
    return URL_DEFAULT_NETWORK_INDEX;
}


#pragma mark -
#pragma mark 悬浮按钮图标数组
- (NSArray<NSString *> *)arrayOfAssistiveTouchButtonImages
{
    return @[ ICON_WEB_VIEW_BUTTON_CLEAR_CACHE,
              ICON_WEB_VIEW_BUTTON_RETURN_BACK,
              ICON_WEB_VIEW_BUTTON_REFRESH,
              ICON_WEB_VIEW_BUTTON_HOME
           ];
}


#pragma mark -
#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 初始化加载网页
    [self webViewStartLoadRequest];
}


@end
