
#import "AppDelegate.h"
#import "JSLAppMainViewController.h"
#import "JSLLauncherViewController.h"

@interface AppDelegate ()
@property (nonatomic, strong) JSLLauncherViewController *launcherViewController;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // 初始化悬浮按钮位置
    APPINFORMATION.touchButtonOriginX = [NSNumber numberWithFloat:SCREEN_MIN_LENGTH-FULL_SUSPEND_BALL_SIZE];
    APPINFORMATION.touchButtonOriginY = [NSNumber numberWithFloat:SCREEN_MAX_LENGTH*0.6f];
    
    // 设置根据视图控制器
    [self setWindow:[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]]];
    [self.window setBackgroundColor:[UIColor blackColor]];
    [self.window makeKeyAndVisible];
    
    // 显示并加载启动广告
    WEAKSELF(weakSelf);
    [self setLauncherViewController:[[JSLLauncherViewController alloc] init]];
    [self.launcherViewController setDoAfterLauncherADPage:^{
        // 删除广告页
        [weakSelf.launcherViewController.view removeFromSuperview];
        [weakSelf setLauncherViewController:nil];
        // 重置主页面
        JSLAppMainViewController *mainViewController = [[JSLAppMainViewController alloc] initWithLocalHTMLString:URL_DEFAULT_NETWORK_INDEX];
        JSLNavigationController *rootViewController = [[JSLNavigationController alloc] initWithRootViewController:mainViewController];
        [weakSelf.window setRootViewController:rootViewController];
    }];
    [self.window setRootViewController:self.launcherViewController];
    
    return YES;
}

@end

