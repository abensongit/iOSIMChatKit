

#import "JSLLauncherViewController.h"

@interface JSLLauncherViewController ()
@property (nonatomic, strong) UIImageView *launcherImageView;
@end

@implementation JSLLauncherViewController

#pragma mark -
#pragma mark 事件处理 - 跳过
- (void)removeLauncherViewController
{
    // 移除启动页
    if (self.doAfterLauncherADPage) {
        self.doAfterLauncherADPage();
    }
}

#pragma mark -
#pragma mark 设置状态栏是否隐藏
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

#pragma mark -
#pragma mark 视图生命周期
- (void)viewDidLoad
{
    [super viewDidLoad];

    // 设置背景颜色
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    // 显示启动图片
    WEAKSELF(weakSelf);
    UIImageView *launcherImageView = ({
        UIImageView *imageView = [[UIImageView alloc] init];
        [imageView setImage:[UIImage imageNamed:[JSLAppUtil getLauncherImageUrl]]];
        [self.view addSubview:imageView];
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(weakSelf.view.mas_top);
            make.left.equalTo(weakSelf.view.mas_left);
            make.bottom.equalTo(weakSelf.view.mas_bottom);
            make.right.equalTo(weakSelf.view.mas_right);
        }];
        
        imageView;
    });
    self.launcherImageView = launcherImageView;
    self.launcherImageView.mas_key = @"launcherImageView";
    
    // 启动图片
    [self viewDidLoadWithLauncherPicture];
}


#pragma mark 创建广告页面 - 启动图片
- (void)viewDidLoadWithLauncherPicture
{
    WEAKSELF(weakSelf);
    __block NSInteger timeOut = 0.0f;
    dispatch_queue_t  queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(timer, dispatch_walltime(NULL, 0), 1.0 * NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(timer, ^{
        if (timeOut <= 0) {
            dispatch_source_cancel(timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                // 启动图显示后操作处理
                [weakSelf removeLauncherViewController];
            });
        } else {
            timeOut--;
        }
    });
    dispatch_resume(timer);
}



@end


