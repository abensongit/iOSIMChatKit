//
//  main.m
//  Captain
//
//  Created by MGN on 2017/12/15.
//  Copyright © 2017年 Captain.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
