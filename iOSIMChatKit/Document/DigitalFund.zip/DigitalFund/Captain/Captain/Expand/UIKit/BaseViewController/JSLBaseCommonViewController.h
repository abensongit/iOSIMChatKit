
#import "JSLBaseCoreViewController.h"

@interface JSLBaseCommonViewController : JSLBaseCoreViewController


@end
