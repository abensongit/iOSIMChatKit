
#ifndef _JSL_ASSETS_MACRO_H_
#define _JSL_ASSETS_MACRO_H_

#pragma mark -
#pragma mark 图标：导航栏按钮
#define ICON_NAVIGATION_BAR_BUTTON_BACK_ARROW_DEF                   @"icon_navbar_btn_back_arrow_white"
#define ICON_NAVIGATION_BAR_BUTTON_BACK_ARROW_WHITE                 @"icon_navbar_btn_back_arrow_white"
#define ICON_NAVIGATION_BAR_BUTTON_BACK_ARROW_BLACK                 @"icon_navbar_btn_back_arrow_black"
//
#define ICON_NAVIGATION_BAR_BUTTON_MORE_DEF                         @"icon_navbar_btn_more_point_white"
#define ICON_NAVIGATION_BAR_BUTTON_MORE_WHITE                       @"icon_navbar_btn_more_point_white"
#define ICON_NAVIGATION_BAR_BUTTON_MORE_BLACK                       @"icon_navbar_btn_more_point_black"
//
#define ICON_NAVIGATION_BAR_BUTTON_CLOSE_WHITE                      @"icon_navbar_btn_close_white"
#define ICON_NAVIGATION_BAR_BUTTON_CLOSE_BLACK                      @"icon_navbar_btn_close_black"


#pragma mark -
#pragma mark 图标：网页浏览器
#define ICON_WEB_VIEW_ERROR_PICTURE                                 @"icon_webview_error"
#define ICON_WEB_VIEW_BUTTON_TOUCH_SETTING                          @"icon_button_setting"
#define ICON_WEB_VIEW_BUTTON_TOUCH_CLOSE                            @"icon_button_close"
//
#define ICON_WEB_VIEW_BUTTON_HOME                                   @"icon_button_home"
#define ICON_WEB_VIEW_BUTTON_REFRESH                                @"icon_button_refresh"
#define ICON_WEB_VIEW_BUTTON_RETURN_BACK                            @"icon_button_back"
#define ICON_WEB_VIEW_BUTTON_CLEAR_CACHE                            @"icon_button_clear"


#pragma mark -
#pragma mark 图标：按钮图标
#define ICON_POP_ALERT_VIEW_NOTICE_BUTTON_CLOSE                     @"icon_pop_notice_close"


#endif /* _JSL_ASSETS_MACRO_H_ */
