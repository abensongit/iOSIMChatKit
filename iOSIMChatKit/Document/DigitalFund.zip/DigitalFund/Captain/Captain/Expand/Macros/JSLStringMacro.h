
#ifndef _JSL_STRING_MACRO_H_
#define _JSL_STRING_MACRO_H_

#pragma mark - 导航栏按钮标题 - 返回/默认
#define STR_NAVIGATION_BAR_BUTTON_TITLE_EMPTY                                    @""
#define STR_NAVIGATION_BAR_BUTTON_TITLE_RETURN_BACK                              @"返回"

#endif /* _JSL_STRING_MACRO_H_ */

