

#ifndef _SYS_URL_MACRO_H_
#define _SYS_URL_MACRO_H_


#pragma mark -
#pragma mark 默认网络
#define URL_DEFAULT_NETWORK_INDEX                   @"Web/index.html"
#define URL_DEFAULT_NETWORK_BAIDU                   @"https://www.baidu.com"


#endif /* _SYS_URL_MACRO_H_ */

