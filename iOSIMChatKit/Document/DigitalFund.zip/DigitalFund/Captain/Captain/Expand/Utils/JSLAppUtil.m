
#import "JSLAppUtil.h"

@implementation JSLAppUtil


#pragma mark -
#pragma mark 获取根视图控制器
+ (UIViewController *)getAppRootViewController
{
    UIWindow *window = [[UIApplication sharedApplication].delegate window];
    UIViewController *rootViewController = window.rootViewController;
    return rootViewController;
}

#pragma mark 获取根顶部控制器
+ (UIViewController*)getTopViewController
{
    return [[self class] topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
}

#pragma mark 获取根顶部控制器 - 帮助
+ (UIViewController*)topViewControllerWithRootViewController:(UIViewController*)rootViewController
{
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController* tabBarController = (UITabBarController*)rootViewController;
        return [[self class] topViewControllerWithRootViewController:tabBarController.selectedViewController];
    } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* navigationController = (UINavigationController*)rootViewController;
        return [[self class] topViewControllerWithRootViewController:navigationController.visibleViewController];
    } else if (rootViewController.presentedViewController) {
        UIViewController* presentedViewController = rootViewController.presentedViewController;
        return [[self class] topViewControllerWithRootViewController:presentedViewController];
    } else {
        return rootViewController;
    }
}


#pragma mark -
#pragma mark 获取应用版本信息
+ (NSString *)getAppVersion
{
    // 版本号数
    NSString *version = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    // 正式版本
    return [NSString stringWithFormat:@"%@", version];
}


#pragma mark -
#pragma mark 获取启动图图片地址
+ (NSString *)getLauncherImageUrl
{
    if (IS_IPHONE_4_OR_LESS) {
        return @"icon_launch_image_se";
    } else if (IS_IPHONE_5) {
        return @"icon_launch_image_se";
    } else if (IS_IPHONE_6) {
        return @"icon_launch_image_8";
    } else if (IS_IPHONE_6P) {
        return @"icon_launch_image_8plus";
    } else if (IS_IPHONE_X || IS_IPHONE_XS) {
        return @"icon_launch_image_xs";
    } else if (IS_IPHONE_XR) {
        return @"icon_launch_image_xr";
    } else if (IS_IPHONE_XSMAX) {
        return @"icon_launch_image_xsmax";
    }
    return @"icon_launch_image_8plus";
}

@end
