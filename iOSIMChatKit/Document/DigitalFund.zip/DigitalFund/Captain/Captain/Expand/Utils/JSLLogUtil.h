
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JSLLogUtil : NSObject

+ (NSString *)getCurrentTimeStamp;

@end

NS_ASSUME_NONNULL_END
