
#import <UIKit/UIKit.h>

@interface UIViewController (AlterMessage)


- (void)alertPromptInfoMessage:(NSString *)message;

- (void)alertPromptErrorMessage:(NSString *)message;

- (void)alertPromptMessage:(NSString *)message;


@end
