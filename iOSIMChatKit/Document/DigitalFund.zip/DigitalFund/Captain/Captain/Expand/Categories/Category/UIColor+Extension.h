//
//  UIColor+Extension.h
//  ItemOne
//
//  Created by JM on 15/12/25.
//  Copyright © 2015年 DD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extension)
+(UIColor*)colorWithHexString:(NSString*)stringToConvert;
@end
