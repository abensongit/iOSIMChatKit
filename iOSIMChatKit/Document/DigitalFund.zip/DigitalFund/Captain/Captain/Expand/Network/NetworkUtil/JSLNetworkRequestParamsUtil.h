//
//  JSLNetworkRequestParamsUtil.h
//  SHISHIBOOKAPP
//
//  Created by HANSEN on 2018/10/29.
//  Copyright © 2018年 HANSEN. All rights reserved.
//

#import <Foundation/Foundation.h>

#define JSL_MOBILE_IOS                @"iOS"
#define JSL_PARAMS_NULL               @""
#define JSL_PARAMS_ZERO               @"0"
#define JSL_PARAMS_MAKE(PARAM)        [JSLNetworkRequestParamsUtil makeRequestParameters:PARAM]
#define JSL_PARAMS_NONNULL(PARAM)     [JSLNetworkRequestParamsUtil makeStringWithNoWhitespaceAndNewline:PARAM]

@interface JSLNetworkRequestParamsUtil : NSObject

#pragma mark -
#pragma mark 参数空白字符串处理
+ (NSString *)makeStringWithNoWhitespaceAndNewline:(NSString *)value;
#pragma mark 公共请求参数的处理
+ (NSMutableDictionary *)makeRequestParameters:(NSMutableDictionary *)params;

#pragma mark -
#pragma mark 网络接口 - 应用数据
+ (NSMutableDictionary *)getApplicationParameters;

#pragma mark 网络接口 - 版本更新
+ (NSMutableDictionary *)getCheckVersionParameters;


@end

