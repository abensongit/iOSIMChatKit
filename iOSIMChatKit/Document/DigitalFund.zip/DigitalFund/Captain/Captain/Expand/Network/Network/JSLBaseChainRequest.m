
#import "JSLBaseChainRequest.h"

@implementation JSLBaseChainRequest

@end
