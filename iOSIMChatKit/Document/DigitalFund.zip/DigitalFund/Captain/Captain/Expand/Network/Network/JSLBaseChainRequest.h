
#if __has_include(<YTKNetwork/YTKNetwork.h>)
#import <YTKNetwork/YTKChainRequest.h>
#else
#import "YTKChainRequest.h"
#endif

@interface JSLBaseChainRequest : YTKChainRequest

@end
