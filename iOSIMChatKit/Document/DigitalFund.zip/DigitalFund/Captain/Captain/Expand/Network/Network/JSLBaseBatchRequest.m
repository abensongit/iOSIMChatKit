
#import "JSLBaseBatchRequest.h"

@implementation JSLBaseBatchRequest

@end
