
#import <Foundation/Foundation.h>

@interface NSString (JSLNetworkUrlUtil)

- (NSString *)networkUrlStringByAppendURLParameters:(NSDictionary *)parameters;

@end

