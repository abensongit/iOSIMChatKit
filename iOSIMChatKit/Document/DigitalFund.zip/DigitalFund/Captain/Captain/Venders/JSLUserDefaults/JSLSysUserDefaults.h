
#import <Foundation/Foundation.h>

@interface JSLSysUserDefaults : NSObject

+ (instancetype)standardUserDefaults;

@end
