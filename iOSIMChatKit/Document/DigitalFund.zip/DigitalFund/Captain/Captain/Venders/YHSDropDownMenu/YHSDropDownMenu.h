

#import "YHSDropDownMenuBasedCell.h"
#import "YHSDropDownMenuBasedModel.h"


#ifdef DEBUG

#define YHSDEBUGLog(...) NSLog(@"\n\n--------------------------------------------------\n%s方法中的第  %d  行打印: \n%@\n--------------------------------------------------\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])

#else

#define YHSDEBUGLog(...)

#endif

