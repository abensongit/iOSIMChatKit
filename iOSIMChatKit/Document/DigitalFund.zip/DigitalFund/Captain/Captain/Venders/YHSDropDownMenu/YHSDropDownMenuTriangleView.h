

#import <UIKit/UIKit.h>
/**
 *  下拉菜单的三角形 
 */
@interface YHSDropDownMenuTriangleView : UIView

/** 三角形的颜色 */
@property (nonatomic, strong) UIColor *triangleColor;

@end
