

#import "YHSDropDownMenuBasedModel.h"

@implementation YHSDropDownMenuBasedModel

@end
